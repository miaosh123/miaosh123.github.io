#!/usr/bin/env python3
"""
OICQ99a 服务端
"""

import socket
import struct
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('oicq_server.log', encoding='utf-8', mode='w'),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

class OICQ99aServer:
    VERSION = 0x0A1B
    
    # OICQ 状态码
    STATUS_ONLINE = 0x01    # 我在线
    STATUS_OFFLINE = 0x00   # 离线
    STATUS_AWAY = 0x04      # 离开
    STATUS_BUSY = 0x05      # 忙碌

    def __init__(self, port=8000):
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(('0.0.0.0', port))
        
        # 用户数据库: {UIN: {"password": str, "nickname": str}}
        self.users = {}
        self.friends = {}       # {UIN: [friend_uin1, friend_uin2, ...]}
        self.online_users = {}  # {UIN: addr}
        
        log.info(f"OICQ99a 服务端启动，监听 UDP {port}")

    def make_packet(self, cmd, seq, uin, body=b''):
        packet = b'\x02'
        packet += struct.pack('>H', self.VERSION)
        packet += struct.pack('>H', cmd)
        packet += struct.pack('>H', seq)
        packet += struct.pack('>I', uin)
        packet += body
        packet += b'\x03'
        return packet

    def handle(self, data, addr):
        if len(data) < 12:
            return None

        cmd = struct.unpack('>H', data[3:5])[0]
        seq = struct.unpack('>H', data[5:7])[0]
        uin = struct.unpack('>I', data[7:11])[0]
        body = data[11:]
        if body and body[-1] == 0x03:
            body = body[:-1]

        log.info(f">>> CMD=0x{cmd:04X} SEQ={seq} UIN={uin} body={body}")

        # CMD=0x0000: 注册/登录
        if cmd == 0x0000:
            # body 格式: 密码(字符串，以0x1e分隔)
            password = body.decode('gbk', errors='ignore').rstrip('\x00') if body else str(uin)
            
            # 第一次登录，自动创建用户
            if uin not in self.users:
                self.users[uin] = {
                    "password": password if password else str(uin),  # 密码默认是UIN
                    "nickname": f"User{uin}",
                    "online": False
                }
                log.info(f"[注册] 新用户 UIN={uin}, 密码={self.users[uin]['password']}")
            else:
                log.info(f"[登录] UIN={uin}")
            
            reply_body = bytes([0x00]) + struct.pack('>I', uin) + bytes([0x01])
            return self.make_packet(0x0000, seq, uin, reply_body)

        # CMD=0x0001: 登录验证（无密码验证）
        elif cmd == 0x0001:
            # 自动创建未注册的用户
            if uin not in self.users:
                self.users[uin] = {
                    "password": str(uin),
                    "nickname": f"User{uin}"
                }
                self.friends[uin] = []
                log.info(f"[登录] 自动创建用户 UIN={uin}")
            
            self.online_users[uin] = addr
            log.info(f"[登录] 成功 UIN={uin}, 在线用户: {list(self.online_users.keys())}")
            return self.make_packet(0x0001, seq, uin, bytes([0x00]))  # 成功

        # CMD=0x0002: 获取等级/状态
        elif cmd == 0x0002:
            body = struct.pack('>II', 1, 0)
            return self.make_packet(0x0002, seq, uin, body)

        # CMD=0x0004: 修改个人设置
        elif cmd == 0x0004:
            log.info(f"[修改设置] UIN={uin} body={body}")
            # 解析: 昵称(0x1f)生日(0x1f)邮箱(0x1f)...
            parts = body.split(b'\x1f') if body else []
            if uin in self.users:
                if len(parts) > 0 and parts[0]:
                    self.users[uin]['nickname'] = parts[0].decode('gbk', errors='ignore')
                if len(parts) > 1:
                    self.users[uin]['birthday'] = parts[1].decode('gbk', errors='ignore')
                if len(parts) > 2:
                    self.users[uin]['email'] = parts[2].decode('gbk', errors='ignore')
                log.info(f"[修改设置] 更新用户 UIN={uin}")
            return self.make_packet(0x0004, seq, uin, bytes([0x00]))

        # CMD=0x0003: 用户注册
        elif cmd == 0x0003:
            log.info(f"[注册] UIN={uin} body={body}")
            # 解析注册信息: 密码(0x1f)昵称(0x1f)生日(0x1f)邮箱(0x1f)...
            parts = body.split(b'\x1f') if body else []
            password = parts[0].decode('gbk', errors='ignore') if len(parts) > 0 else str(uin)
            nickname = parts[1].decode('gbk', errors='ignore') if len(parts) > 1 else f"User"
            
            # 分配 UIN
            assigned_uin = uin if uin != 0 else (max(self.users.keys()) + 1 if self.users else 10001)
            
            # 创建用户
            self.users[assigned_uin] = {
                "password": password,
                "nickname": nickname if nickname and nickname != '-' else f"User{assigned_uin}",
                "online": False
            }
            self.friends[assigned_uin] = []  # 初始化好友列表
            log.info(f"[注册] 新用户 UIN={assigned_uin}, 昵称={self.users[assigned_uin]['nickname']}")
            
            # 返回成功 + UIN
            reply_body = bytes([0x00]) + struct.pack('>I', assigned_uin)
            return self.make_packet(0x0003, seq, assigned_uin, reply_body)

        # CMD=0x0005: 搜索/查找
        elif cmd == 0x0005:
            log.info(f"[查找] body={body}")
            # 解析搜索条件: 模式(0x1f)关键词(0x1f)...
            parts = body.split(b'\x1f')
            search_mode = parts[0][0] if parts and parts[0] else 0
            
            # 搜索所有用户
            results = []
            for user_uin, user_info in self.users.items():
                if user_uin != uin:  # 不显示自己
                    results.append((user_uin, user_info))
            
            log.info(f"[查找] 找到 {len(results)} 个结果")
            # 返回格式: 数量(2字节) + [UIN(4字节) + 昵称 + 0x00 + 状态(1字节) + 0x1f分隔]
            body = struct.pack('>H', len(results))
            for user_uin, user_info in results:
                body += struct.pack('>I', user_uin)
                body += user_info['nickname'].encode('gbk') + b'\x00'
                status = self.STATUS_ONLINE if user_uin in self.online_users else self.STATUS_OFFLINE
                body += bytes([status, 0x1f])  # 状态 + 分隔
            return self.make_packet(0x0005, seq, uin, body)

        # CMD=0x0006: 获取用户资料 (OICQ99a格式)
        elif cmd == 0x0006:
            log.info(f"[用户资料] UIN={uin}")
            # 自动创建不存在的用户
            if uin not in self.users:
                self.users[uin] = {
                    "password": str(uin),
                    "nickname": f"User{uin}",
                    "online": False
                }
            user_info = self.users[uin]
            # OICQ99a 格式: 状态(1) + 昵称 + 分隔 + UIN + 分隔 + ...
            body = bytes([0x02])  # 成功状态
            body += user_info['nickname'].encode('gbk') + b'\x00'
            body += bytes([0x1e])  # 分隔
            body += struct.pack('>I', uin)  # UIN
            body += bytes([0x1e])  # 分隔
            body += b"19800101"  # 生日
            body += bytes([0x1e])  # 分隔
            body += struct.pack('>H', 10)  # 等级
            body += bytes([0x1e])  # 分隔
            body += bytes([0x00])  # 结束
            return self.make_packet(0x0006, seq, uin, body)

        # CMD=0x000E: 
        elif cmd == 0x000E:
            return self.make_packet(0x000E, seq, uin, bytes([0x01]))

        # CMD=0x0011: IM消息
        elif cmd == 0x0011:
            log.info(f"[IM] {body}")
            return self.make_packet(0x0011, seq, uin, bytes([0x01]))

        # CMD=0x0013: 加好友
        elif cmd == 0x0013:
            log.info(f"[加好友] UIN={uin} body={body}")
            # body 格式: "1\x1fUIN" (OICQ99a格式)
            try:
                parts = body.split(b'\x1f')
                action = parts[0][0] if parts else 0
                friend_uin = int(parts[1]) if len(parts) > 1 else 0
                
                if friend_uin not in self.friends:
                    self.friends[friend_uin] = []
                
                if friend_uin not in self.friends[uin]:
                    self.friends[uin].append(friend_uin)
                    log.info(f"[加好友] {uin} 添加好友 {friend_uin}")
                
                return self.make_packet(0x0013, seq, uin, bytes([0x00]))  # 成功
            except Exception as e:
                log.error(f"[加好友] 解析错误: {e}")
                return self.make_packet(0x0013, seq, uin, bytes([0x01]))

        # CMD=0x0014: 
        elif cmd == 0x0014:
            log.info(f"[0x0014] body={body}")
            return self.make_packet(0x0014, seq, uin, bytes([0x00]))

        # CMD=0x0015: 好友列表
        elif cmd == 0x0015:
            friend_list = self.friends.get(uin, [])
            log.info(f"[好友列表] UIN={uin}, 好友={friend_list}")
            # 格式: 状态(1) + 数量(2) + [UIN(4) + 昵称 + 0x00 + 0x1f + 状态(1)]
            body = bytes([0x00])  # 成功状态
            body += struct.pack('>H', len(friend_list))
            for friend_uin in friend_list:
                if friend_uin not in self.users:
                    continue
                user_info = self.users[friend_uin]
                body += struct.pack('>I', friend_uin)
                body += user_info['nickname'].encode('gbk') + b'\x00'
                body += bytes([0x1f])  # 分隔符
                # 在线状态
                status = self.STATUS_ONLINE if friend_uin in self.online_users else self.STATUS_OFFLINE
                body += bytes([status])
            return self.make_packet(0x0015, seq, uin, body)

        # CMD=0x0016: 在线好友
        elif cmd == 0x0016:
            online_friends = list(self.online_users.keys())
            body = struct.pack('>H', len(online_friends))
            for friend_uin in online_friends:
                if friend_uin == uin:
                    continue
                body += struct.pack('>I', friend_uin)
                body += bytes([self.STATUS_ONLINE])  # 在线状态
            return self.make_packet(0x0016, seq, uin, body)

        else:
            log.info(f"[未知CMD] 0x{cmd:04X}")
            return None

    def run(self):
        log.info("等待数据包...")
        while True:
            try:
                data, addr = self.sock.recvfrom(65535)
                reply = self.handle(data, addr)
                if reply:
                    self.sock.sendto(reply, addr)
                    log.info(f"<<< 回复: {reply.hex()}")
            except Exception as e:
                log.error(f"错误: {e}")

if __name__ == '__main__':
    server = OICQ99aServer(port=8000)
    server.run()
